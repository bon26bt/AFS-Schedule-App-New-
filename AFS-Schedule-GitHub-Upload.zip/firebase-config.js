// Firebase web app configuration for AFS Schedule
// Measurement ID is optional for Firebase app initialization.
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyB428pHezZ8e9UVRyqczUIhf_FgvjtdvHo",
  authDomain: "afs-schedule.firebaseapp.com",
  projectId: "afs-schedule",
  storageBucket: "afs-schedule.firebasestorage.app",
  messagingSenderId: "590915203901",
  appId: "1:590915203901:web:a92e619d7c64a876964b54",
  measurementId: "G-FWT7E68YJZ"
};
