const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore } = require('firebase-admin/firestore');

initializeApp();
const db = getFirestore();
const DOMAIN = '@afs-jimma.app';

exports.adminCreateStaff = onCall({ region: 'us-central1' }, async (request) => {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'Admin sign-in is required.');
  }

  const adminSnap = await db.collection('users').doc(request.auth.uid).get();
  const adminProfile = adminSnap.exists ? adminSnap.data() : null;
  if (!adminProfile || adminProfile.active !== true || adminProfile.role !== 'admin') {
    throw new HttpsError('permission-denied', 'Only an active administrator can create staff accounts.');
  }

  const username = String(request.data?.username || '').trim().toLowerCase();
  const password = String(request.data?.password || '');
  if (!/^[a-z0-9._-]{3,30}$/.test(username)) {
    throw new HttpsError('invalid-argument', 'Username must be 3–30 characters: letters, numbers, dot, underscore or hyphen.');
  }
  if (password.length < 8 || password.length > 128) {
    throw new HttpsError('invalid-argument', 'Password must be at least 8 characters.');
  }

  const email = username + DOMAIN;
  let createdUser;
  try {
    createdUser = await getAuth().createUser({ email, password, displayName: username, disabled: false });
    await db.collection('users').doc(createdUser.uid).create({
      username,
      role: 'user',
      active: true,
      createdAt: new Date().toISOString(),
      createdBy: request.auth.uid
    });
    return { uid: createdUser.uid, username };
  } catch (error) {
    if (createdUser) {
      try { await getAuth().deleteUser(createdUser.uid); } catch (_) {}
    }
    if (error.code === 'auth/email-already-exists') {
      throw new HttpsError('already-exists', 'This username already exists.');
    }
    if (error instanceof HttpsError) throw error;
    console.error('adminCreateStaff failed:', error);
    throw new HttpsError('internal', 'Could not create the staff account.');
  }
});
